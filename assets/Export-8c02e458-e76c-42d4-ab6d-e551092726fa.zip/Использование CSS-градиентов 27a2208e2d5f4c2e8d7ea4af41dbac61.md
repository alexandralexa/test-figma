# Использование CSS-градиентов.

**CSS-градиенты** представлены типом данных `[<gradient>` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient), специальным типом `[<image>` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/image), состоящим из последовательного перехода между двумя и более цветами. Вы можете выбрать один из трёх типов градиентов: *линейный* (создаётся с помощью функции `[linear-gradient](https://developer.mozilla.org/ru/docs/orphaned/Web/CSS/linear-gradient())`), *круговой* (создаётся с помощью `[radial-gradient](https://developer.mozilla.org/ru/docs/orphaned/Web/CSS/radial-gradient())`) и конический (создаётся с помощью функции `[conic-gradient` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/conic-gradient())). Вы можете также создавать повторяющиеся градиенты с помощью функций `[repeating-linear-gradient](https://developer.mozilla.org/ru/docs/orphaned/Web/CSS/repeating-linear-gradient())`, `[repeating-radial-gradient` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/repeating-radial-gradient()) и `[repeating-conic-gradient` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/repeating-conic-gradient()).

Градиенты могут быть использованы везде, где может быть использован тип `<image>`, например в качестве фона. Так как градиенты генерируются динамически, они могут избавить от необходимости использовать файлы растровых изображений, которые ранее использовались для достижения похожих эффектов. В дополнение к этому, так как градиенты генерируются браузером, они выглядят лучше, чем растровые изображения в случае увеличения масштаба, и их размер может быть изменён на лету.

Мы начнём с того, что покажем вам линейные градиенты, затем покажем возможности, поддерживаемые всеми типами градиентов, используя линейные градиенты в качестве примера, затем перейдём к круговым, коническим и повторяющимся градиентам.

## [Использование линейных градиентов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5_%D0%BB%D0%B8%D0%BD%D0%B5%D0%B9%D0%BD%D1%8B%D1%85_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%B2)

Линейный градиент создаёт цветную полосу, имеющую вид прямой линии.

### Обычный линейный градиент

Чтобы создать самый простой тип градиента, всё, что вам нужно – это указать два цвета. Они называются *точки остановки цвета*. Их должно быть, как минимум, две, но у вас может быть столько, сколько захотите.

`.simple-linear {
  background: linear-gradient(blue, pink);
}`Copy to Clipboard

### Изменение направления

По умолчанию линейные градиенты идут сверху вниз. Вы можете изменить угол поворота путём задания направления.

`.horizontal-gradient {
  background: linear-gradient(to right, blue, pink);
}`
Copy to Clipboard

### Диагональные градиенты

Вы можете даже создать градиент, проходящий диагонально, из угла в угол.

`.diagonal-gradient {
  background: linear-gradient(to bottom right, blue, pink);
}`
Copy to Clipboard

### Использование углов

Если вы хотите больше контроля над его направлением, вы можете задать градиенту определённый угол.

`.angled-gradient {
  background: linear-gradient(70deg, blue, pink);
}`
Copy to Clipboard

При использовании угла `0deg` создаётся вертикальный градиент, идущий снизу вверх, `90deg` создаёт горизонтальный градиент, идущий слева направо, и так далее по часовой стрелке. Отрицательные углы идут против часовой стрелки.

![https://developer.mozilla.org/files/3811/linear_red_angles.png](https://developer.mozilla.org/files/3811/linear_red_angles.png)

## [Указание цветов и создание эффектов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D1%83%D0%BA%D0%B0%D0%B7%D0%B0%D0%BD%D0%B8%D0%B5_%D1%86%D0%B2%D0%B5%D1%82%D0%BE%D0%B2_%D0%B8_%D1%81%D0%BE%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5_%D1%8D%D1%84%D1%84%D0%B5%D0%BA%D1%82%D0%BE%D0%B2)

Все типы CSS-градиентов – это диапазон позиционно-зависимых цветов. Цвета, создаваемые CSS-градиентами, могут варьироваться непрерывно с изменением позиции, создавая плавные цветовые переходы. Возможно также создавать полосы сплошных цветов, и резкие переходы между двумя цветами. Следующее примеры работают во всех градиентных функциях:

### Использование более двух цветов

Вам не нужно ограничиваться двумя цветами – вы можете использовать столько, сколько хотите! По умолчанию цвета равномерно распределены по градиенту.

`.auto-spaced-linear-gradient {
  background: linear-gradient(red, yellow, blue, orange);
}`
Copy to Clipboard

### Расположение точек остановок цветов

Вам не нужно оставлять ваши точки остановок цветов на их исходных позициях. Чтобы подправить их расположение, вы можете не задавать каждому ничего, или задать одну или две процентные, а для круговых и линейных градиентов – абсолютные значения. Если вы зададите расположение с процентах, `0%` будет представлять начальную точку, в то время как `100%` будет являться конечной точкой; однако, если необходимо, вы можете использовать значения и вне этого диапазона для достижения желаемого эффекта. Если вы не будете задавать расположение, позиция этой точки остановки будет автоматически рассчитана за вас так, что первая точка остановки будет расположена на `0%`, а последняя – на `100%`, а все остальные точки остановки будут расположены на полпути между соседними точками остановки.

`.multicolor-linear {
   background: linear-gradient(to left, lime 28px, red 77%, cyan);
}`
Copy to Clipboard

### Создание резких переходов

Чтобы создать резкий переход между двумя цветами, т. е. получить черту вместо постепенного перехода, обе соседние точки остановки должны быть установлены в одном месте. В этом примере цвета делят точку остановки на отметке `50%`, посередине градиента:

`.striped {
   background: linear-gradient(to bottom left, cyan 50%, palegoldenrod 50%);
}`Copy to Clipboard

### Подсказки градиента

По умолчанию градиент идёт плавно от одного цвета до другого. Вы можете добавить цветовую подсказку, чтобы переместить значение средней точки перехода в определённую точку градиента. В этом примере мы переместили среднюю точку перехода из отметки 50% на отметку 10%.

`.color-hint {
  background: linear-gradient(blue, 10%, pink);
}
.simple-linear {
  background: linear-gradient(blue, pink);
}`Copy to Clipboard

### Создание цветных линий и полосок

Чтобы добавить внутрь градиента сплошную цветную область без плавного перехода, добавьте две позиции для точки остановки. Точки остановки могут быть в двух позициях, что эквивалентно двум подряд точкам остановки с тем же цветом на разных позициях. Цвет достигнет полной насыщенности на первой точке, проследует с той же насыщенностью до второй точки остановки и перейдёт в цвет следующей точки остановки через первую позицию следующей точки остановки.

`.multiposition-stops {
   background: linear-gradient(to left,
       lime 20%, red 30%, red 45%, cyan 55%, cyan 70%, yellow 80% );
   background: linear-gradient(to left,
       lime 20%, red 30% 45%, cyan 55% 70%, yellow 80% );
}
.multiposition-stop2 {
   background: linear-gradient(to left,
      lime 25%, red 25%, red 50%, cyan 50%, cyan 75%, yellow 75% );
   background: linear-gradient(to left,
      lime 25%, red 25% 50%, cyan 50% 75%, yellow 75% );
}`
Copy to Clipboard

В первом примере выше лаймовый цвет идёт от отметки 0%, далее, как указано, до отметки 20%, сделает переход от лаймового до красного через 10% ширины градиента, достигнет сплошного красного на отметке 30%, и останется таким до 45% градиента, где он потускнеет до голубого, оставаясь таким ещё 15% градиента, и так далее.

Во втором примере каждая вторая точка остановки для каждого цвета находится на той же позиции, что и первая точка остановки соседнего цвета, создавая полосатый эффект.

В обоих примерах градиент написан дважды: первый – это метод из CSS-изображений уровня 3 использующий повторения цвета на каждой остановке, а второй пример – это метод из CSS-изображений уровня 4, где в линейном объявлении точек остановки используются множественные точки остановки с двумя значениями длин точек остановки.

### Управление переходом градиента

По умолчанию градиент плавно переходит между цветами двух соседних точек остановки, а средняя точка между этими двумя точками остановки является средним значением цветового перехода. Вы можете контролировать интерполяцию или переход между двумя точками остановки добавлением его расположения в цветовой подсказке. В этом примере цвет достигает средней точки перехода от лаймового до голубого на расстоянии 20% градиента вместо стандартных 50%. Во втором примере нет такой подсказки, чтобы подчеркнуть отличие, получаемое при её использовании:

`.colorhint-gradient {
  background: linear-gradient(to top, black, 20%, cyan);
}
.regular-progression {
  background: linear-gradient(to top, black, cyan);
}`
Copy to Clipboard

### [Перекрытие градиентов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%BF%D0%B5%D1%80%D0%B5%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%B2)

Градиенты поддерживают прозрачность, так что вы можете накладывать фоны для получения всяких разных эффектов. Фоны накладываются снизу вверх таким образом, что первый объявленный будет лежать поверх остальных.

`.layered-image {
  background: linear-gradient(to right, transparent, mistyrose),
      url("https://mdn.mozillademos.org/files/15525/critters.png");
}`
Copy to Clipboard

### [Наслаивание градиентов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%BD%D0%B0%D1%81%D0%BB%D0%B0%D0%B8%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%B2)

Вы можете даже наслаивать градиенты друг на друга. Если верхние градиенты не полностью непрозрачны, градиенты, лежащие под ними, тоже будут видны.

`.stacked-linear {
  background:
      linear-gradient(217deg, rgba(255,0,0,.8), rgba(255,0,0,0) 70.71%),
      linear-gradient(127deg, rgba(0,255,0,.8), rgba(0,255,0,0) 70.71%),
      linear-gradient(336deg, rgba(0,0,255,.8), rgba(0,0,255,0) 70.71%);
}`
Copy to Clipboard

## [Использование круговых градиентов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5_%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%B2%D1%8B%D1%85_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%B2)

Круговые градиенты схожи с линейными градиентами, за исключением того, что они создают градиентный круг по направлению от центральной точки. Вы можете указать, где должна находиться центральная точка. Вы также можете сделать её круглой или овальной.

### [Обычный круговой градиент](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%BE%D0%B1%D1%8B%D1%87%D0%BD%D1%8B%D0%B9_%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%B2%D0%BE%D0%B9_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82)

Как и в случае с линейными градиентами, всё, что вам нужно, чтобы создать круговой градиент – это два цвета. По умолчанию центр градиента находится на отметке 50% 50%, градиент становится овальным с учётом соотношения сторон содержащего его блока:

`.simple-radial {
  background: radial-gradient(red, blue);
}`
Copy to Clipboard

### [Размещение круговых точек остановки](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D1%80%D0%B0%D0%B7%D0%BC%D0%B5%D1%89%D0%B5%D0%BD%D0%B8%D0%B5_%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%B2%D1%8B%D1%85_%D1%82%D0%BE%D1%87%D0%B5%D0%BA_%D0%BE%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%BA%D0%B8)

Опять же, как и у линейных градиентов, вы можете расположить каждую круговую точку остановки, указав значение в виде процентной или абсолютной длины.

`.radial-gradient {
  background: radial-gradient(red 10px, yellow 30%, #1e90ff 50%);
}`
Copy to Clipboard

### [Расположение центра градиента](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D1%80%D0%B0%D1%81%D0%BF%D0%BE%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5_%D1%86%D0%B5%D0%BD%D1%82%D1%80%D0%B0_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%B0)

Вы можете расположить центр градиента с помощью ключевых значений, процентной или абсолютной длины. Значения в виде числа или процента повторяются в случае, если указано только одно из них, иначе порядок повторения будет определяться порядком расположения, начиная слева и сверху.

`.radial-gradient {
  background: radial-gradient(at 0% 30%, red 10px, yellow 30%, #1e90ff 50%);
}`
Copy to Clipboard

### [Задание размеров кругового градиента](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%B7%D0%B0%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5_%D1%80%D0%B0%D0%B7%D0%BC%D0%B5%D1%80%D0%BE%D0%B2_%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%B2%D0%BE%D0%B3%D0%BE_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%B0)

В отличие от линейных градиентов, круговому градиенту можно задавать размеры. Возможные значения включат в себя: ближайший угол, ближайшая сторона, самый дальний угол и самая дальняя сторона, самый дальний угол – значение по умолчанию.

### Пример: ближайшая сторона для эллипса

В этом примере используется значение размера `closest-side`, которое означает, что размер определяется расстоянием от начальной точки (центра) до ближайшей стороны блока.

`.radial-ellipse-side {
  background: radial-gradient(ellipse closest-side,
      red, yellow 10%, #1e90ff 50%, beige);
}`
Copy to Clipboard

### Пример: самый дальний угол для эллипса

Этот пример схож с предыдущим, за исключением того, что его размер указан как `farthest-corner`, что устанавливает размер градиента значением расстояния от начальной точки до самого дальнего угла блока.

`.radial-ellipse-far {
  background: radial-gradient(ellipse farthest-corner at 90% 90%,
      red, yellow 10%, #1e90ff 50%, beige);
}`
Copy to Clipboard

### Пример: ближайшая сторона для круга

Этот пример использует `closest-side`, что задаёт размер круга как расстояние между начальной точкой (центром) и ближайшей стороной. Радиус круга – это расстояние между центром градиента и ближайшей стороной. Круг, с учётом позиционирования в точке 25% от левой стороны и 25% от низа, ближе всего к низу, так как расстояние по высоте в этом случае меньше, чем по ширине.

`.radial-circle-close {
  background: radial-gradient(circle closest-side at 25% 75%,
      red, yellow 10%, #1e90ff 50%, beige);
}`
Copy to Clipboard

### [Наложение круговых градиентов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%BD%D0%B0%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5_%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%B2%D1%8B%D1%85_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%B2)

Вы можете накладывать круговые градиенты так же, как линейные. Первый объявленный будет сверху, последний – снизу.

`.stacked-radial {
  background:
      radial-gradient(circle at 50% 0,
        rgba(255,0,0,.5),
        rgba(255,0,0,0) 70.71%),
      radial-gradient(circle at 6.7% 75%,
        rgba(0,0,255,.5),
        rgba(0,0,255,0) 70.71%),
      radial-gradient(circle at 93.3% 75%,
        rgba(0,255,0,.5),
        rgba(0,255,0,0) 70.71%) beige;
  border-radius: 50%;
}`
Copy to Clipboard

## [Использование конических градиентов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5_%D0%BA%D0%BE%D0%BD%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D1%85_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%B2)

[CSS](https://developer.mozilla.org/en-US/docs/Web/CSS)-функция **`conic-gradient()`** создаёт изображение, состоящее из градиента с переходом цвета, обёрнутым вокруг центральной точки (в отличие от градиента, исходящего кругом от центральной точки). Образцом конического градиента можно назвать круговые диаграммы и цветовые круги, но он также может быть использован для создания шахматной доски (клетки) и других интересных эффектов.

Синтаксис конического градиента схож с синтаксисом кругового градиента, но с тем отличием, что точки остановки цвета располагаются вокруг градиентной дуги, вдоль длины окружности круга, а не по градиентной линии, идущей от центра градиента. Также, точки остановки цвета задаются только в процентах или градусах, абсолютные величины недопустимы.

В круговом градиенте цвета переходят от центра окружности наружу, во всех направлениях. В случае конического градиента цвета идут, как бы оборачиваясь вокруг центра круга, начиная сверху и двигаясь по часовой стрелке. Так же, как и в круговом градиенте, вы можете указать расположение центра градиента. Так же, как и в линейном градиенте, вы можете изменять угол градиента.

### Обычный конический градиент

Так же, как и в случае с линейными и круговыми градиентами, всё, что вам нужно для создания конического градиента – это два цвета. По умолчанию центр градиента находится в точке 50% 50%, начало градиента направлено вверх:

`.simple-conic {
  background: conic-gradient(red, blue);
}`
Copy to Clipboard

### Расположение конического центра

Как и в круговом градиенте, вы можете задать расположение центра конического градиента с помощью ключевых значений, процентных или абсолютных величин с использованием ключевого слова "at".

`.conic-gradient {
  background: conic-gradient(at 0% 30%, red 10%, yellow 30%, #1e90ff 50%);
}`
Copy to Clipboard

### Изменение угла

Вы можете задать угол, в котором направлено начало градиента значением типа `[<angle>](https://developer.mozilla.org/ru/docs/Web/CSS/angle)`, с предшествующим ему ключевым словом "from".

`.conic-gradient {
  background: conic-gradient(from 45deg, red, orange, yellow, green, blue, purple);
}`
Copy to Clipboard

## [Использование повторяющихся градиентов](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5_%D0%BF%D0%BE%D0%B2%D1%82%D0%BE%D1%80%D1%8F%D1%8E%D1%89%D0%B8%D1%85%D1%81%D1%8F_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%B2)

Функции `[linear-gradient](https://developer.mozilla.org/ru/docs/orphaned/Web/CSS/linear-gradient())`, `[radial-gradient](https://developer.mozilla.org/ru/docs/orphaned/Web/CSS/radial-gradient())` и `[conic-gradient` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/conic-gradient()) не поддерживают автоматически повторяющиеся точки остановки цвета. Однако, для реализации этой функциональности существуют функции `[repeating-linear-gradient](https://developer.mozilla.org/ru/docs/orphaned/Web/CSS/repeating-linear-gradient())`, `[repeating-radial-gradient` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/repeating-radial-gradient()) и `[repeating-conic-gradient` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/repeating-conic-gradient()).

Размер повторяющейся градиентной линии или дуги – это длина от значения первой до значения последней точки остановки цвета. Если первая точка остановки содержит только цвет без указания длины до точки остановки, то используется значение по умолчанию, равное 0. Если последняя точка остановки содержит только цвет без указания длины до точки установки, то используется значение по умолчанию, равное 100%. Если ни то, ни другое не определено, то линия градиента будет равна 100%, что означает, что линейный и конический градиент не будет повторяться, а круговой градиент будет повторяться, только если радиус градиента меньше, чем расстояние между центром градиента и самым дальним углом. Если первая точка остановки определена и имеет значение больше 0, градиент будет повторяться при условии, что размер линии или дуги равен разнице между первой и последней точкой остановки, если эта разница меньше, чем 100% или 360 градусов.

### Повторяющиеся линейные градиенты

В этом примере используется `[repeating-linear-gradient](https://developer.mozilla.org/ru/docs/orphaned/Web/CSS/repeating-linear-gradient())` для создания повторяющегося градиента, идущего по прямой линии. Цветовая последовательность начинается заново с каждым повторением градиента. В данном случае градиент имеет длину 10px.

`.repeating-linear {
  background: repeating-linear-gradient(-45deg, red, red 5px, blue 5px, blue 10px);
}`
Copy to Clipboard

### Множественные повторяющиеся линейные градиенты

Так же, как и в случае с обычными линейными и круговыми градиентами, вы можете использовать множественные градиенты, один поверх другого. Это имеет смысл, только если градиенты частично прозрачны, что позволяет видеть одни градиенты сквозь прозрачные части других градиентов, этого же можно достичь при условии использования разных [размеров фона (background-size)](https://developer.mozilla.org/en-US/docs/Web/CSS/background-size), при этом возможно ещё и при разных значениях свойства [background-position](https://developer.mozilla.org/en-US/docs/Web/CSS/background-position) для каждого градиента. Мы использовали прозрачность.

В данном случае градиентные линии имеют длину 300px, 230px и 300px.

`.multi-repeating-linear {
  background:
      repeating-linear-gradient(190deg, rgba(255, 0, 0, 0.5) 40px,
        rgba(255, 153, 0, 0.5) 80px, rgba(255, 255, 0, 0.5) 120px,
        rgba(0, 255, 0, 0.5) 160px, rgba(0, 0, 255, 0.5) 200px,
        rgba(75, 0, 130, 0.5) 240px, rgba(238, 130, 238, 0.5) 280px,
        rgba(255, 0, 0, 0.5) 300px),
      repeating-linear-gradient(-190deg, rgba(255, 0, 0, 0.5) 30px,
        rgba(255, 153, 0, 0.5) 60px, rgba(255, 255, 0, 0.5) 90px,
        rgba(0, 255, 0, 0.5) 120px, rgba(0, 0, 255, 0.5) 150px,
        rgba(75, 0, 130, 0.5) 180px, rgba(238, 130, 238, 0.5) 210px,
        rgba(255, 0, 0, 0.5) 230px),
      repeating-linear-gradient(23deg, red 50px, orange 100px,
        yellow 150px, green 200px, blue 250px,
        indigo 300px, violet 350px, red 370px);
}`
Copy to Clipboard

### [Клетчатый градиент](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%BA%D0%BB%D0%B5%D1%82%D1%87%D0%B0%D1%82%D1%8B%D0%B9_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82)

Для создания клетчатого градиента мы используем несколько полупрозрачных перекрывающих друг друга градиентов. В первом объявлении фона мы внесли в список каждую остановку цвета отдельно. Во втором объявлении свойства background используется синтаксис многопозиционных остановок цвета:

`.plaid-gradient {
  background:
      repeating-linear-gradient(90deg, transparent, transparent 50px,
        rgba(255, 127, 0, 0.25) 50px, rgba(255, 127, 0, 0.25) 56px,
        transparent 56px, transparent 63px,
        rgba(255, 127, 0, 0.25) 63px, rgba(255, 127, 0, 0.25) 69px,
        transparent 69px, transparent 116px,
        rgba(255, 206, 0, 0.25) 116px, rgba(255, 206, 0, 0.25) 166px),
      repeating-linear-gradient(0deg, transparent, transparent 50px,
        rgba(255, 127, 0, 0.25) 50px, rgba(255, 127, 0, 0.25) 56px,
        transparent 56px, transparent 63px,
        rgba(255, 127, 0, 0.25) 63px, rgba(255, 127, 0, 0.25) 69px,
        transparent 69px, transparent 116px,
        rgba(255, 206, 0, 0.25) 116px, rgba(255, 206, 0, 0.25) 166px),
      repeating-linear-gradient(-45deg, transparent, transparent 5px,
        rgba(143, 77, 63, 0.25) 5px, rgba(143, 77, 63, 0.25) 10px),
      repeating-linear-gradient(45deg, transparent, transparent 5px,
        rgba(143, 77, 63, 0.25) 5px, rgba(143, 77, 63, 0.25) 10px);

  background:
      repeating-linear-gradient(90deg, transparent 0 50px,
        rgba(255, 127, 0, 0.25) 50px 56px,
        transparent 56px 63px,
        rgba(255, 127, 0, 0.25) 63px 69px,
        transparent 69px 116px,
        rgba(255, 206, 0, 0.25) 116px 166px),
      repeating-linear-gradient(0deg, transparent 0 50px,
        rgba(255, 127, 0, 0.25) 50px 56px,
        transparent 56px 63px,
        rgba(255, 127, 0, 0.25) 63px 69px,
        transparent 69px 116px,
        rgba(255, 206, 0, 0.25) 116px 166px),
      repeating-linear-gradient(-45deg, transparent 0 5px,
        rgba(143, 77, 63, 0.25) 5px 10px),
      repeating-linear-gradient(45deg, transparent 0 5px,
        rgba(143, 77, 63, 0.25) 5px 10px);
}`
Copy to Clipboard

### [Повторяющиеся круговые градиенты](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%BF%D0%BE%D0%B2%D1%82%D0%BE%D1%80%D1%8F%D1%8E%D1%89%D0%B8%D0%B5%D1%81%D1%8F_%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%B2%D1%8B%D0%B5_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D1%8B)

В этом примере для создания кругового градиента, повторяющегося из центральной точки, используется `[repeating-radial-gradient` (en-US)](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/repeating-radial-gradient()). Цветовая последовательность начинаются заново с каждой итерацией повторения градиента.

`.repeating-radial {
  background: repeating-radial-gradient(black, black 5px, white 5px, white 10px);
}`
Copy to Clipboard

### [Множественные повторяющиеся круговые градиенты](https://developer.mozilla.org/ru/docs/Web/CSS/CSS_Images/Using_CSS_gradients#%D0%BC%D0%BD%D0%BE%D0%B6%D0%B5%D1%81%D1%82%D0%B2%D0%B5%D0%BD%D0%BD%D1%8B%D0%B5_%D0%BF%D0%BE%D0%B2%D1%82%D0%BE%D1%80%D1%8F%D1%8E%D1%89%D0%B8%D0%B5%D1%81%D1%8F_%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%B2%D1%8B%D0%B5_%D0%B3%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D1%8B)

`.multi-target {
  background:
      repeating-radial-gradient(ellipse at 80% 50%,rgba(0,0,0,0.5),
        rgba(0,0,0,0.5) 15px, rgba(255,255,255,0.5) 15px,
        rgba(255,255,255,0.5) 30px) top left no-repeat,
      repeating-radial-gradient(ellipse at 20% 50%,rgba(0,0,0,0.5),
        rgba(0,0,0,0.5) 10px, rgba(255,255,255,0.5) 10px,
        rgba(255,255,255,0.5) 20px) top left no-repeat yellow;
  background-size: 200px 200px, 150px 150px;
}`
Copy to Clipboard